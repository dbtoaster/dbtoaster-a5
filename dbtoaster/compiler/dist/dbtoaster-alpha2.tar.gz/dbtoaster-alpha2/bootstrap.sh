#!/bin/sh

STAGEDIR=`pwd`

OCAML=ocaml-3.11.1
OCAMLDIR="$OCAML"
OCAMLDIST="$OCAMLDIR.tar.gz"

XMLLIGHT=xml-light-2.2
XMLLIGHTDIR="$XMLLIGHT"
XMLLIGHTDIST="$XMLLIGHTDIR.tar.gz"

BOOST=boost_1_40_0
BOOSTDIR="$BOOST"
BOOSTDIST="$BOOSTDIR.tar.bz2"

THRIFT=thrift
THRIFTDIR="$THRIFT"
THRIFTDIST="$THRIFTDIR"-HEAD.tar.gz

BUILDDIR=build
INSTALLDIR=software
METADIR=$STAGEDIR/.meta

SRCDIR=src
BINDIR=compiler

# Tools
ECHO=/bin/echo
OCAMLBUILD=$STAGEDIR/$INSTALLDIR/$OCAMLDIR/bin/ocamlbuild

$ECHO "Bootstrapping DBToaster from $STAGEDIR"

create_dir()
{
    ARGDIR=$1
    test -d $ARGDIR || \
        ($ECHO "Creating '$ARGDIR' ... " && mkdir $ARGDIR)

    if [ ! -d $ARGDIR ]; then
        $ECHO "Failed to create '$ARGDIR'"
        exit 1
    fi
}

# Build OCaml
setup_ocaml()
{
    if [[ ! ( -f $METADIR/built_ocaml && -f $METADIR/installed_ocaml ) ]]; then
        rm $METADIR/built_ocaml $METADIR/installed_ocaml

        test -d $BUILDDIR/$OCAMLDIR && \
            $ECHO "Cleaning previous OCaml build ... " && \
            rm -rf $BUILDDIR/$OCAMLDIR

        test -d $STAGEDIR/$INSTALLDIR/$OCAMLDIR && \
            $ECHO "Cleaning previous OCaml install ... " && \
            rm -rf $STAGEDIR/$INSTALLDIR/$OCAMLDIR

        $ECHO -n "Extracing OCaml ... " && \
            tar zxf dist/$OCAMLDIST -C $BUILDDIR/ && $ECHO "done."

        cd $BUILDDIR/$OCAMLDIR/
        ./configure -prefix $STAGEDIR/$INSTALLDIR/$OCAMLDIR
        $ECHO -n "Building OCaml ... " && \
            (make world.opt 2>&1 > make_world_opt.log) && \
            touch $METADIR/built_ocaml && $ECHO "done."

        if [ -f $METADIR/built_ocaml ]; then
            $ECHO -n "Installing OCaml ... " && make install && \
                (touch $METADIR/installed_ocaml && $ECHO "done.") || $ECHO "failed."
        else
            $ECHO "failed to build OCaml."
            exit 1
        fi

        cd $STAGEDIR

        if [ -f $METADIR/installed_ocaml ]; then
            #rm -rf $BUILDDIR/$OCAMLDIR
            $ECHO "Keeping OCaml dir while testing script..."
        fi
    fi

    # TODO: ensure ocamlc is on the path
}

# Build xml-light
setup_xmllight()
{
    if [[ ! ( -f $METADIR/built_xml_light && -f $METADIR/installed_xml_light ) ]]; then
        rm $METADIR/built_xml_light $METADIR/installed_xml_light

        test -d $BUILDDIR/$XMLLIGHTDIR && \
            $ECHO "Cleaning previous XML-Light build ... " && \
            rm -rf $BUILDDIR/$XMLLIGHTDIR

        test -d $STAGEDIR/$INSTALLDIR/$XMLLIGHTDIR && \
            $ECHO "Cleaning previous XML-Light install ... " && \
            rm -rf $STAGEDIR/$INSTALLDIR/$XMLLIGHTDIR

        $ECHO -n "Extracting XML-Light ... " && \
            tar zxf dist/$XMLLIGHTDIST -C $BUILDDIR/ && $ECHO "done."

        cd $BUILDDIR/$XMLLIGHTDIR/

        INSTALLSEDSTR=`echo "$STAGEDIR/$INSTALLDIR/$XMLLIGHTDIR" | sed 's/\//\\\\\//g;'`
        sed "s/INSTALLDIR=.*/INSTALLDIR=$INSTALLSEDSTR\//" < Makefile > Makefile.new
        mv Makefile.new Makefile

        $ECHO -n "Building XML-Light ... " && \
            env PATH="$STAGEDIR/$INSTALLDIR/$OCAMLDIR/bin:$PATH" make && \
            touch $METADIR/built_xml_light && $ECHO "done."

        if [ -f $METADIR/built_xml_light ]; then
            $ECHO -n "Installing XML-Light ... " && \
            create_dir $STAGEDIR/$INSTALLDIR/$XMLLIGHTDIR && \
            env PATH="$STAGEDIR/$INSTALLDIR/$OCAMLDIR/bin:$PATH" make install && \
                (touch $METADIR/installed_xml_light && $ECHO "done.") || $ECHO "failed."
        else
            $ECHO "failed to build XML-Light."
            exit 1
        fi

        cd $STAGEDIR

        if [ -f $METADIR/installed_xml_light ]; then
            #rm -rf $BUILDDIR/$XMLLIGHTDIR
            $ECHO "Keeping XML-Light dir while testing script..."
        fi
    fi
}

# Build Boost
setup_boost()
{
    if [[ ! ( -f $METADIR/built_boost && -f $METADIR/installed_boost ) ]]; then
        rm $METADIR/built_boost $METADIR/installed_boost

        test -d $BUILDDIR/$BOOSTDIR && \
            $ECHO "Cleaning previous Boost build ... " && \
            rm -rf $BUILDDIR/$BOOSTDIR

        test -d $STAGEDIR/$INSTALLDIR/$BOOSTDIR && \
            $ECHO "Cleaning previous Boost install ... " && \
            rm -rf $STAGEDIR/$INSTALLDIR/$BOOSTDIR

        $ECHO -n "Extracting Boost ... " && \
            tar jxf dist/$BOOSTDIST -C $BUILDDIR/ && $ECHO "done."

        cd $BUILDDIR/$BOOSTDIR/

        $ECHO -n "Building boost ... " && \
        ./bootstrap.sh --prefix=$STAGEDIR/$INSTALLDIR/$BOOSTDIR --with-libraries=date_time,filesystem,iostreams,serialization,system,thread  && \
        touch $METADIR/built_boost && $ECHO "done."

        if [ -f $METADIR/built_boost ]; then
            $ECHO -n "Installing boost ... " && \
            ./bjam install && \
                (touch $METADIR/installed_boost && $ECHO "done.") || \
                $ECHO "failed."
        else
            $ECHO "Failed to build boost."
        fi

        cd $STAGEDIR
    fi
}


# Set up Thrift
setup_thrift()
{
    if [[ ! ( -f $METADIR/built_thrift && -f $METADIR/installed_thrift ) ]]; then
        rm $METADIR/built_thrift $METADIR/installed_thrift

        test -d $BUILDDIR/$THRIFTDIR && \
            $ECHO "Cleaning previous Thrift build ... " && \
            rm -rf $BUILDDIR/$THRIFTDIR

        test -d $STAGEDIR/$INSTALLDIR/$THRIFTDIR && \
            $ECHO "Cleaning previous Thrift install ... " && \
            rm -rf $STAGEDIR/$INSTALLDIR/$THRIFTDIR

        $ECHO -n "Extracting Thrift ... " && \
            tar zxf dist/$THRIFTDIST -C $BUILDDIR/ && $ECHO "done."

        cd $BUILDDIR/$THRIFTDIR/

        ./bootstrap.sh

        ./configure --prefix=$STAGEDIR/$INSTALLDIR/$THRIFTDIR --with-boost=$STAGEDIR/$INSTALLDIR/$BOOSTDIR --enable-gen-cpp --enable-gen-java --with-java=yes

        $ECHO -n "Building Thrift ... " && \
            make && \
            (touch $METADIR/built_thrift && $ECHO "done.")

        if [ -f $METADIR/built_thrift ]; then
            $ECHO -n "Installing Thrift ... " && \
                make install && \
                (touch $METADIR/installed_thrift && $ECHO "done.") || \
                $ECHO "failed."
        else
            $ECHO "Failed to build Thrift."
        fi
    fi
}

setup_dbtoaster()
{
    # Setup myocamlbuild
    INSTALLXMLLIGHTDIRSTR=`echo "$STAGEDIR/$INSTALLDIR/$XMLLIGHTDIR" | sed 's/\//\\\\\//g;'`

    sed "s/@XMLLIGHTDIR@/$INSTALLXMLLIGHTDIRSTR/" \
        < $SRCDIR/myocamlbuild.ml.in > $SRCDIR/myocamlbuild.ml

    # Compile DBToaster
    cd $SRCDIR
    $OCAMLBUILD -no-log dbtoaster.byte

    cd $STAGEDIR
    cp $SRCDIR/_build/dbtoaster.byte $BINDIR/

    test -d $BINDIR/examples || cp -R $SRCDIR/examples $BINDIR/
    test -d $BINDIR/profiler || cp -R $SRCDIR/profiler $BINDIR/
    test -d $BINDIR/standalone || cp -R $SRCDIR/standalone $BINDIR/
}

create_dir $METADIR
create_dir $BUILDDIR
create_dir $BINDIR

setup_ocaml
setup_xmllight
setup_boost

# Build DBToaster
setup_dbtoaster

