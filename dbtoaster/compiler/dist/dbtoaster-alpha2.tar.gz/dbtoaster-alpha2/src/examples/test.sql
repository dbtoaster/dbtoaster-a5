CREATE TABLE R (A int, B int);
CREATE TABLE S (B int, C int);
CREATE TABLE T (C int, D int);

SELECT sum(A*D) FROM R,S,T WHERE R.B=S.B AND S.C = T.C ;

/*

CREATE TABLE BIDS (T int, ID int, P int, V int);

-- two level nesting: VWAP
SELECT sum(B2.P*B2.V) FROM BIDS B2
    WHERE 0.25*(SELECT sum(BIDS.V) FROM BIDS) >
        (SELECT sum(B1.V) FROM BIDS B1 WHERE B1.P > B2.P);

-- three level nesting 
SELECT sum(B2.P*B2.V) FROM BIDS B2
    WHERE 0.25*(SELECT sum(BIDS.V) FROM BIDS) >
        (SELECT sum(B1.V) FROM BIDS B1
         WHERE
             B1.V < (SELECT max(B3.V) FROM BIDS B3 WHERE B1.P < B3.P)
             AND B1.P > B2.P);
*/

/*
CREATE TABLE PART (
    partkey int, name text,
    mfgr text, brand text,
    type text, size integer,
    container text, retailprice float,
    comment text
);

CREATE TABLE PARTSUPP (
    partkey int,
    suppkey int,
    availqty int,
    supplycost float,
    comment text
);

SELECT PS.suppkey, sum(PS.availqty)
    FROM PART P, PARTSUPP PS
    WHERE P.partkey = PS.partkey
    GROUP BY PS.suppkey;

-- keywords, table and field names are auto-uppercased
select PS.suppkey, sum(PS.availqty)
    from part P, partsupp PS
    where P.partkey = PS.partkey
    group by ps.suppkey;
*/

-- queries that should fail...

/*
SELECT sum(E) FROM R,S,T WHERE R.B=S.B AND S.C=T.C;
SELECT sum(A*D) FROM R,S,T WHERE R.B=S.B AND S.D=T.D;

-- keywords, table and field names are auto-uppercased
select PS.supplykey, sum(PS.availqty)
    from part P, partsupp PS
    where P.partkey = PS.partkey
    group by ps.suppkey;
*/